# Linux Server Configuration

1. IP address : 52.41.156.162  
   SSH Port : 2200
   username : grader (root is disable)
   grader password: !Bc1212**&
   
2. URL: http://ec2-52-41-156-162.us-west-2.compute.amazonaws.com/

3. Installed software summary:
   ``
   Flask
   postgresql
   sqlalchemy
   pip
   redis
   oauth2client
   bleach
   requests
   httplib2
   passlib
   itsdangerous
   flask-httpauth
   ``

4. Thirdparty resource
    
   Stack-overflow
   Github


5. udacity_key.rsa:
-----BEGIN RSA PRIVATE KEY-----
MIIEpgIBAAKCAQEA2B4YHcC6SeR36mKPB4e2NuIwEWY7DvPS0NvDysSTVhS7AbRK
RC+7Y5r9m+dTKtN4YLM7Oa0KErzul1IOfMzG2pxKpahKcoUKZauMLzK6adOlwMmC
xBDOA2V8ccifC75aoBbuYTeEynJC+gf4uZxBZxuze39YC5KyS8W+kG5hWeuTLF6+
Lz3h8LDBCPEHF/773VT5CRbWeepsSomXIZTyM0ZyV+p7l5lMeWV79GVIJV0EM4CO
fjtwb5MVnnlPUuQQqbprOrhgfvHpmVvZrknZvx9cSn2XnE2wiXuEp0+TpqZOUQU0
oPTeH3iVAYrwIrQa/l1hoHRG0MoynlT3NqlvLQIDAQABAoIBAQCRHNvqlm8/kHXo
XpdVYg26mnPWKwO6zYMflIDKFOYtZawPv+QiFr7HadmiJlhUqDvrCk3ZM1RRMqUt
2/44VDOttEX3J6IddTF/BQoS4wgCaQeiBGyWhAYgh7Ngn2oTs5QcbGlRw7qZSNGq
G1IqJz5PIm2IngAbfTvU3wlO557chbKXb13xycyVja9sXbS9LQMrWJ3Vfkqec+Kl
TODOCexWWegly/bAj5kl92guao4hO0jmmZVnc4drV94qxeaVdYJbb2s0wKArQJXq
4485dr0ZznSmJ9U2zlUwa8G1vaTbOtma/f/b9jFUeUV5Ge9GS3uOUG14doQJZnff
Vmj+U23NAoGBAO9FJRPsoufzZRX0517ApibKhnFETyOosyT6uuXSxIaWgPI0J/l4
QlMMNuK/VRrO0WoaJ2brIaLF0qPNh8+6s8+5zVgF0dsw9kLn5oTSfu0swxC465iq
xPpg8TKEcodVpn1G55QGA41FqYkeGNyZeCIpBKpa0gJVJTqwe/2VVKufAoGBAOc6
hs2eQBHczB6IUUy7v0naL6Kmmpa7U9YRGmU4k0mkbQlTCcOPh1HSCAWJTuj6RW4k
euzeq7gcI9V+5IR3rH/glinRf1pvnxB27+ZxH3GOnF3g7hu8i3yOAQbO2z2/pPia
+ujFlbMmwmq6tX5NvubpKT8GRP4HCPtQ5p2C5DGzAoGBANDTOi8PgoaKKRlmq2BJ
JzoH3BqTEbb/j4qgwem/cAI+7L92wcS7Lreom2Z+sto40xCVTvpGEQ8tNE/+G6Az
RKfxc8R1H9j7/JIcL1aRGHILdRvtKMIPmOclIJ2EdyiimjIQZiEMtqDfwb2IZQ5z
ayP1RLshlNSwV1PHoA+L+1/lAoGBAIH0acjsVPP1FR9f29l1d2fpYXZXjnCCrfaU
vDIBXv43lDR2X/lyFEqO8YUzC49zAUyK4i94YihiYF1gKMyueduQ/LRaEupf65UU
U3Y/Q73NueIlRY1/JSIGqVsLLTsCF5TFfZkPWzhJ42CauOBYj581kcHjIylmCM0+
Ra5m3xtzAoGBALw0fnVjXhMvznOuTlFv/v5fmyhj1G5LjxdkCWpLTPjf0Ean2uF9
pLdubze97nmvDmARqxbyBKn4i8jUGXaXRze+y6w9U2J7ifk7QOVxXay7lZEvzMBv
2ME/llItcpqI3p0/f4mtpbIfwQEKeJcrEy8ekImtcK6rYHEkZqGwLO9K
-----END RSA PRIVATE KEY-----




